# Property Glance — Meta Ray-Ban Display Web App

Look at a house → gesture → its **address, est. value, last sale + date, beds/baths, lot, year built**
read out on the 600×600 in-lens display. No camera, no ML — it works by **ray-casting** your GPS
position along your compass heading into a parcel map, then enriching the hit with property data.

Built against the Meta Ray-Ban Display (MRBD) Web App spec:
https://wearables.developer.meta.com/docs/develop/webapps/

---

## What's in the box
```
property-glance/
  index.html            the whole app (config · geo math · data providers · UI)
  manifest.webmanifest  app manifest (PNG icons, per spec)
  icons/                96 / 192 / 180px PNG icons
  README.md
```

## Try it right now (off-glasses preview)
Open `index.html` on your phone or desktop and pick **Demo**. Arrow keys (or tap) drive it:
- **← / →** move focus across Prev · Re-lock · Next
- **Enter** activates the focused control
- **Esc** back to the start screen

Demo mode cycles four sample parcels (HB / Long Beach / Newport Coast / Seal Beach) so you can
feel the lock animation and card layout without any keys or GPS.

## Run it on the glasses
1. Register at the **Meta Wearables Developer Center** and create a Web App
   (https://wearables.developer.meta.com/docs/develop/webapps/setup/).
2. Host this folder at an **HTTPS URL** — drag it into Vercel/Netlify, or `npx serve`.
   It's static; no build step.
3. Add the URL to your Web App in the dev center and open it on MRBD per the Test guide
   (https://wearables.developer.meta.com/docs/develop/webapps/test/).
4. On the glasses, choose **Live**. Grant motion + location when prompted (the prompt only
   fires from the button press — that's required by the platform).

Tip: Meta ships an AI-coding plugin (`facebookincubator/meta-wearables-webapp`) that drops these
best practices into Claude Code / Cursor / Copilot if you want to extend this with AI assistance.

## Go live (real data)
Everything live-related is isolated in two places, so the UI never has to change.

**1. Keys — edit the `CONFIG` block at the top of the script in `index.html`:**
```js
const CONFIG = {
  provider: 'demo',
  attomKey:  'YOUR_ATTOM_KEY',   // property facts  → api.developer.attomdata.com (30-day trial)
  parcelKey: 'YOUR_REGRID_KEY',  // parcel polygons → regrid.com
};
```

**2. Providers — `DemoProvider` and `LiveProvider`:**
- `LiveProvider._ensureParcels()` pulls parcels near you (Regrid) and caches them until you move ~80m.
- `rayCast()` projects your look-direction and returns every parcel the ray crosses, nearest first —
  that ranked list is exactly what **Prev / Next** cycle through to absorb GPS/compass error.
- `LiveProvider._enrich()` maps an ATTOM `property/detail` response onto the card fields.

> The two live endpoints are marked **VERIFY** in the code. Confirm the exact paths/params and
> response shape against each provider's current docs before shipping — field names drift between
> API versions. Until keys are added, Live mode shows a friendly "add a key" message instead of failing.

## Display notes (why it looks the way it does)
The lens is an **additive waveguide**: pure black renders as *transparent*, and only bright colors add
light. So the UI is bright amber/white/cyan on true black — no panels, no blur, no gradients over the
world. The 600×600 viewport is locked and non-scrolling. All input arrives as arrow keys + Enter from
the Neural Band / temple touch strip, so every control is a focusable target with a min 78px height.

## Responsible use
This surfaces **property facts** (largely public record) — not people. It deliberately shows no owner
name, no occupant info, no PII. Keep it that way: a glasses overlay that resolves to *who lives there*
is a very different product, legally and ethically, from one that reads out a house's stats.
